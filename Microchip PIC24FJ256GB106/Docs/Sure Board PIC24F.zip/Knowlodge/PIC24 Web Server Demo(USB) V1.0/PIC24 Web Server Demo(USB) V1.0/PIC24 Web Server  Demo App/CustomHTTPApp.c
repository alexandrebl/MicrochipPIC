/*********************************************************************
 *
 *  Application to Demo HTTP2 Server
 *  Support for HTTP2 module in Microchip TCP/IP Stack
 *	 -Implements the application 
 *	 -Reference: RFC 1002
 *
 *********************************************************************
 * FileName:        CustomHTTPApp.c
 * Dependencies:    TCP/IP stack
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.05 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.30 or higher
 *					HI-TECH PICC-18 PRO 9.63PL2 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2010 Microchip Technology Inc.  All rights
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 *
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Elliott Wood     	6/18/07	Original
 * Yale       	        09/03/10	Port to PIC24 Web Server Demo Board
 ********************************************************************/
#define __CUSTOMHTTPAPP_C

#include "TCPIPConfig.h"

#if defined(STACK_USE_HTTP2_SERVER)

#include "TCPIP Stack/TCPIP.h"

/****************************************************************************
  Section:
	Function Prototypes and Memory Globalizers
  ***************************************************************************/
   
	unsigned int  SUM_ADCVoltage=0;
	unsigned int  AVR_ADCVoltage=0;
	unsigned int  AdcMax = 0;      //minimum value
	unsigned int  AdcMin = 0x3ff;  //maximum value 
	int Temperature;

	const unsigned int TempAD_R[ ]=
	{  
		103 	,108 	,113 	,118 	,123 	,129 	,135 	,140 	,146 	,153 	,
		159 	,166 	,172 	,179 	,186 	,194 	,201 	,209 	,217 	,225 	,
		233 	,241 	,249 	,258 	,267 	,276 	,285 	,294 	,303 	,313 	,
		322 	,332 	,342 	,351 	,361 	,371 	,381 	,391 	,401 	,411 	,
		421 	,432 	,442 	,452 	,462 	,472 	,482 	,492 	,502 	,512 	,
		522 	,532 	,541 	,551 	,561 	,570 	,579 	,589 	,598 	,607 	,
		616 	,625 	,633 	,642 	,650 	,659 	,667 	,675 	,683 	,690 	,
		698 	,705 	,713 	,720 	,727 	,734 	,741 	,747 	,754 	,760 	,
		766 	,772 	,778 	,784 	,790 	,795 	,801 	,806 	,811 	,816 	,
		821 	,826 	,830 	,835 	,839 	,844 	,848 	,852 	,856 	,860 	,
		864 	,868 	,871 	,875 	,878 	,882 	,885 	,888 	,891 	,894 	,
		897 	,900 	,903 	,906 	,908 	,911 	,913 	,916 	,918 	,921 	,
		923 	,925 	,927 	,929 	,931 	,933 	,935 	,937 	,939 	,941 	,
		943 	,944 	,946 	,948 	,950 	,951 	,952 	,954 	,955 	,956 	,
		958 	,959 	,961 	,962 	,963 	,964 	,965 	,966 	,968 	,969 	
	};

	void ThermistorCalculate (void);
	void getAVR_ADCVoltage (void);
  
  
#if defined(HTTP_USE_POST)
	#if defined(USE_LCD)
		static HTTP_IO_RESULT HTTPPostLCD(void);
	#endif
#endif



/****************************************************************************
  Section:
	GET Form Handlers
  ***************************************************************************/
  
/*****************************************************************************
  Function:
	HTTP_IO_RESULT HTTPExecuteGet(void)
	
  Internal:
  	See documentation in the TCP/IP Stack API or HTTP2.h for details.
  ***************************************************************************/
HTTP_IO_RESULT HTTPExecuteGet(void)
{
	BYTE *ptr;
	BYTE filename[20];

	// Load the file name
	// Make sure BYTE filename[] above is large enough for your longest name

#if defined STACK_USE_MDD
	BYTE i,cntr1=0,cntr2=0,filext=0;
	do
	{
		if(curHTTP.file->name[cntr2] != 0x20)
		{
			filename[cntr1]=curHTTP.file->name[cntr2];
			cntr1++;
		}
		else if(filext!=TRUE)
		{
			filename[cntr1]=0x2E;
			cntr1++;
			filext=TRUE;
		}

		cntr2++;

	}while(cntr2 !=FILE_NAME_SIZE);

	for(i=0;i<20;i++) //Convert filename to lower case
		if((filename[i] >= (BYTE)'A') && (filename[i] <= (BYTE)'Z'))
			filename[i] += 'a' - 'A';
#endif	

	// If its the forms.htm page
	if(!memcmppgm2ram(filename, "forms.htm", 9))
	{
		// Seek out each of the four LED strings, and if it exists set the LED states
		
		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led5");
		if(ptr)
			LED5_IO = (*ptr == '1');		
		
		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led4");
		if(ptr)
			LED4_IO = (*ptr == '1');

		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led3");
		if(ptr)
			LED3_IO = (*ptr == '1');

		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led2");
		if(ptr)
			LED2_IO = (*ptr == '1');

		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led1");
		if(ptr)
			LED1_IO = (*ptr == '1');
	}
		
	// If it's the LED updater file
	else if(!memcmppgm2ram(filename, "leds.cgi", 8))
	{
		// Determine which LED to toggle
		ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE *)"led");
		
		// Toggle the specified LED
		switch(*ptr) {
			case '1':
				LED1_IO ^= 1;
				break;
			case '2':
				LED2_IO ^= 1;
				break;
			case '3':
				LED3_IO ^= 1;
				break;
			case '4':
				LED4_IO ^= 1;
				break;
			case '5':
				LED5_IO ^= 1;
				break;
			case '6':
				LED6_IO ^= 1;
				break;
			case '7':
				LED7_IO ^= 1;
				break;
		}
		
	}
	
	return HTTP_IO_DONE;
}


/****************************************************************************
  Section:
	POST Form Handlers
  ***************************************************************************/
#if defined(HTTP_USE_POST)

/*****************************************************************************
  Function:
	HTTP_IO_RESULT HTTPExecutePost(void)
	
  Internal:
  	See documentation in the TCP/IP Stack API or HTTP2.h for details.
  ***************************************************************************/
HTTP_IO_RESULT HTTPExecutePost(void)
{
	// Resolve which function to use and pass along
BYTE filename[20];
	
	// Load the file name
	// Make sure BYTE filename[] above is large enough for your longest name
#if defined STACK_USE_MDD
	BYTE i,cntr1=0,cntr2=0,filext=0;


	
	do
	{
		if(curHTTP.file->name[cntr2] != 0x20)
		{
			filename[cntr1]=curHTTP.file->name[cntr2];
			cntr1++;
		}
		else if(filext!=TRUE)
		{
			filename[cntr1]=0x2E;  //File extension starts after this
			cntr1++;
			filext=TRUE;
		}

		cntr2++;

	}while(cntr2 !=FILE_NAME_SIZE);

	for(i=0;i<20;i++) //Convert file name to lower case
		if((filename[i] >= (BYTE)'A') && (filename[i] <= (BYTE)'Z'))
			filename[i] += 'a' - 'A';
#endif
	
#if defined(USE_LCD)
	if(!memcmppgm2ram(filename, "forms.htm", 9))
		return HTTPPostLCD();
#endif

	return HTTP_IO_DONE;
}

/*****************************************************************************
  Function:
	static HTTP_IO_RESULT HTTPPostLCD(void)

  Summary:
	Processes the LCD form on forms.htm

  Description:
	Locates the 'lcd' parameter and uses it to update the text displayed
	on the board's LCD display.
	
	This function has four states.  The first reads a name from the data
	string returned as part of the POST request.  If a name cannot
	be found, it returns, asking for more data.  Otherwise, if the name 
	is expected, it reads the associated value and writes it to the LCD.  
	If the name is not expected, the value is discarded and the next name 
	parameter is read.
	
	In the case where the expected string is never found, this function 
	will eventually return HTTP_IO_NEED_DATA when no data is left.  In that
	case, the HTTP2 server will automatically trap the error and issue an
	Internal Server Error to the browser.

  Precondition:
	None

  Parameters:
	None

  Return Values:
  	HTTP_IO_DONE - the parameter has been found and saved
  	HTTP_IO_WAITING - the function is pausing to continue later
  	HTTP_IO_NEED_DATA - data needed by this function has not yet arrived
  ***************************************************************************/
#if defined(USE_LCD)
static HTTP_IO_RESULT HTTPPostLCD(void)
{
	BYTE* cDest;
	
	#define SM_POST_LCD_READ_NAME		(0u)
	#define SM_POST_LCD_READ_VALUE		(1u)
	
	switch(curHTTP.smPost)
	{
		// Find the name
		case SM_POST_LCD_READ_NAME:
		
			// Read a name
			if(HTTPReadPostName(curHTTP.data, HTTP_MAX_DATA_LEN) == HTTP_READ_INCOMPLETE)
				return HTTP_IO_NEED_DATA;

			curHTTP.smPost = SM_POST_LCD_READ_VALUE;
			// No break...continue reading value
		
		// Found the value, so store the LCD and return
		case SM_POST_LCD_READ_VALUE:
					
			// If value is expected, read it to data buffer,
			// otherwise ignore it (by reading to NULL)	
			if(!strcmppgm2ram((char*)curHTTP.data, (ROM char*)"lcd"))
				cDest = curHTTP.data;
			else
				cDest = NULL;
			
			// Read a value string
			if(HTTPReadPostValue(cDest, HTTP_MAX_DATA_LEN) == HTTP_READ_INCOMPLETE)
				return HTTP_IO_NEED_DATA;
			
			// If this was an unexpected value, look for a new name
			if(!cDest)
			{
				curHTTP.smPost = SM_POST_LCD_READ_NAME;
				break;
			}
			
			// Copy up to 32 characters to the LCD
			if(strlen((char*)cDest) < 32u)
			{
				memset(LCDText, ' ', 32);
				strcpy((char*)LCDText, (char*)cDest);
			}
			else
			{
				memcpy(LCDText, (void *)cDest, 32);
			}
			LCDUpdate();
			
			// This is the only expected value, so callback is done
			strcpypgm2ram((char*)curHTTP.data, (ROM void*)"/forms.htm");
			curHTTP.httpStatus = HTTP_REDIRECT;
			return HTTP_IO_DONE;
	}
	
	// Default assumes that we're returning for state machine convenience.
	// Function will be called again later.
	return HTTP_IO_WAITING;
}
#endif

#endif //(use_post)


/****************************************************************************
  Section:
	Dynamic Variable Callback Functions
  ***************************************************************************/

/*****************************************************************************
  Function:
	void HTTPPrint_varname(void)
	
  Internal:
  	See documentation in the TCP/IP Stack API or HTTP2.h for details.
  ***************************************************************************/

void HTTPPrint_version(void)
{
	TCPPutROMString(sktHTTP, (ROM void*)TCPIP_STACK_VERSION);
}

ROM BYTE HTML_UP_ARROW[] = "up";
ROM BYTE HTML_DOWN_ARROW[] = "dn";

void HTTPPrint_btn(WORD num)
{
	// Determine which button
	switch(num)
	{
		case 0:
			num = BUTTON0_IO;
			break;
		case 1:
			num = BUTTON1_IO;
			break;
		case 2:
			num = BUTTON2_IO;
			break;
			
		default:
			num = 0;
	}

	// Print the output
	TCPPutROMString(sktHTTP, (num?HTML_UP_ARROW:HTML_DOWN_ARROW));
	return;
}
	
void HTTPPrint_led(WORD num)
{
	// Determine which LED
	switch(num)
	{
		case 0:
			num = LED0_IO;
			break;
		case 1:
			num = LED1_IO;
			break;
		case 2:
			num = LED2_IO;
			break;
		case 3:
			num = LED3_IO;
			break;
		case 4:
			num = LED4_IO;
			break;
		case 5:
			num = LED5_IO;
			break;
		case 6:
			num = LED6_IO;
			break;
		case 7:
			num = LED7_IO;
			break;

		default:
			num = 0;
	}

	// Print the output
	TCPPut(sktHTTP, (num?'1':'0'));
	return;
}

void HTTPPrint_ledSelected(WORD num, WORD state)
{
	// Determine which LED to check
	switch(num)
	{
		case 0:
			num = LED0_IO;
			break;
		case 1:
			num = LED1_IO;
			break;
		case 2:
			num = LED2_IO;
			break;
		case 3:
			num = LED3_IO;
			break;
		case 4:
			num = LED4_IO;
			break;
		case 5:
			num = LED5_IO;
			break;
		case 6:
			num = LED6_IO;
			break;
		case 7:
			num = LED7_IO;
			break;

		default:
			num = 0;
	}
	
	// Print output if TRUE and ON or if FALSE and OFF
	if((state && num) || (!state && !num))
		TCPPutROMString(sktHTTP, (ROM BYTE*)"SELECTED");
	return;
}

void My_strncpy(char *pD, char *pS,int nDestSize)
{
       int nLen=strlen(pS)+1;

       if(nLen>nDestSize) nLen=nDestSize;

       memcpy(pD,pS,nLen);

       *(pD+nLen-1)='\0';
}

void HTTPPrint_pot0(void)
{
	BYTE PUTString[17];
	BYTE tempValue[8];	
	ThermistorCalculate();
	
	if( Temperature < 0)
	{
		tempValue[0] = '-';
		Temperature = -Temperature;
	}
	else
	{	
		tempValue[0]=((unsigned int)(Temperature)/1000)%10+'0';
   		if(tempValue[0]=='0') tempValue[0]=' ';
	}
	
	tempValue[1] = ((unsigned int)(Temperature)/100)%10+'0';	

	if(tempValue[1]=='0' && ( tempValue[0]==' '|| tempValue[0]=='-') ) 
	{
		tempValue[1]=' ';
	}
	
	tempValue[2] = ((unsigned int)(Temperature)/10)%10+'0';
	tempValue[3] = '.';
	tempValue[4] = ((unsigned int)(Temperature)%10)+'0';	
	tempValue[5] = 0;	
	My_strncpy(PUTString, tempValue, 7);
			
   	TCPPutString(sktHTTP, PUTString);
}

void HTTPPrint_pot1(void)
{
	BYTE PUTString[17];	
	My_strncpy(PUTString, PtrRX_WRdata, 17-RX_index);	
	strncat(PUTString,  RX_Buffer  , RX_index );		
   	TCPPutString(sktHTTP, PUTString);
}

void HTTPPrint_lcdtext(void)
{
	WORD len;

	// Determine how many bytes we can write
	len = TCPIsPutReady(sktHTTP);
	
	#if defined(USE_LCD)
	// If just starting, set callbackPos
	if(curHTTP.callbackPos == 0u)
		curHTTP.callbackPos = 32;
	
	// Write a byte at a time while we still can
	// It may take up to 12 bytes to write a character
	// (spaces and newlines are longer)
	while(len > 12u && curHTTP.callbackPos)
	{
		// After 16 bytes write a newline
		if(curHTTP.callbackPos == 16u)
			len -= TCPPutROMArray(sktHTTP, (ROM BYTE*)"<br />", 6);

		if(LCDText[32-curHTTP.callbackPos] == ' ' || LCDText[32-curHTTP.callbackPos] == '\0')
			len -= TCPPutROMArray(sktHTTP, (ROM BYTE*)"&nbsp;", 6);
		else
			len -= TCPPut(sktHTTP, LCDText[32-curHTTP.callbackPos]);

		curHTTP.callbackPos--;
	}
	#else
	TCPPutROMString(sktHTTP, (ROM BYTE*)"No LCD Present");
	#endif

	return;
}

void HTTPPrint_hellomsg(void)
{
	BYTE *ptr;
	
	ptr = HTTPGetROMArg(curHTTP.data, (ROM BYTE*)"name");
	
	// We omit checking for space because this is the only data being written
	if(ptr != NULL)
	{
		TCPPutROMString(sktHTTP, (ROM BYTE*)"Hello, ");
		TCPPutString(sktHTTP, ptr);
	}

	return;
}

//extern APP_CONFIG AppConfig;

void getAVR_ADCVoltage (void)
{
	int ADCVoltage;
	int i;
	
	for(i=0;i<18;i++)
	{  
		AD1CON1 = 0x00E4;          // Off, Auto sample start, auto-convert
		AD1CON1bits.FORM = 0x0;   
		AD1CON2 = 0;               // AVdd, AVss, int every conversion, MUXA only
		AD1CON3 = 0x1F05;          // 31 Tad auto-sample, Tad = 5*Tcy
		AD1CSSL = 0x0000;
		AD1CHS0 = 0;               // select A/D channel
		AD1CON1bits.ADON = 1;      // Turn On mode
		while(!AD1CON1bits.DONE);  // Wait for conversion to complete
		ADCVoltage = ADC1BUF0;
		AD1CON1bits.ADON = 0;      // Turn off module
		SUM_ADCVoltage = SUM_ADCVoltage+ADCVoltage;
            
		if (ADCVoltage > AdcMax)
		{
			AdcMax = ADCVoltage; 
		}
		if (ADCVoltage < AdcMin)
		{
			AdcMin = ADCVoltage; 
		}
	}
		
	SUM_ADCVoltage = SUM_ADCVoltage - AdcMax - AdcMin; 
	AVR_ADCVoltage = SUM_ADCVoltage>>4;
	SUM_ADCVoltage = 0;  
	AdcMax = 0;          
	AdcMin = 0x3ff;      
}


void ThermistorCalculate (void)
{
	unsigned char left  = 0;
	unsigned char right = 149;
	unsigned char middle= 0;
	unsigned int  Deviation = 0;   
	unsigned int  turevalueofAD;  
	int l_tempAD;
	int r_tempAD; 
	int Temp;  
		
	getAVR_ADCVoltage();
	
	turevalueofAD = AVR_ADCVoltage;      
     
	turevalueofAD = turevalueofAD+Deviation;
           
	while( right >= left)
	{         
		middle = ( left + right )/2; 
		if( turevalueofAD < *(TempAD_R+middle) )
		{
			right = middle-1;
		}
		else
		{
			left = middle+1; 
		}
	}
      
	l_tempAD = *(TempAD_R+left-1);  
	r_tempAD = *(TempAD_R+left); 
	     
    Temp = (left-25)*10 + (turevalueofAD-l_tempAD)*10/(r_tempAD-l_tempAD);
	Temperature = ( 9*Temp+1600 )/5;
}


#endif
