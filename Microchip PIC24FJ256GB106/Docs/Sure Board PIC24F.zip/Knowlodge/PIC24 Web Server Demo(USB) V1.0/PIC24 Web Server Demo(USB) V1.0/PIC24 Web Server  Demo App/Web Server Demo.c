/*********************************************************************
 *
 *  Main Application Entry Point 
 *
 *********************************************************************
 * FileName:        Web Server Demo.c
 * Dependencies:    TCPIP.h
 * Processor:       PIC24FJ256GB106
 * Compiler:        Microchip C30 v3.12 or higher
 * Company:         Sure Electronics Co., Ltd.
 *
 * Software License Agreement
 *
 * Copyright (C) 2010 Sure Electronics Co., Ltd.
 * All rights reserved.
 *
 * Author              Date         Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Yale		           09/03/10     Port to PIC24 Web Server Demo Board
 ********************************************************************/
/*
 * This macro uniquely defines this file as the main entry point.
 * There should only be one such definition in the entire project,
 * and this file must define the AppConfig variable as described below.
 */
#define THIS_IS_STACK_APPLICATION

// Include all headers for any enabled TCPIP Stack functions
#include "TCPIP Stack/TCPIP.h"

// Include functions specific to this stack application

#ifdef USE_USB_INTERFACE
#include "USB/usb.h"
#include "USB/usb_host_msd.h"
#include "USB/usb_host_msd_scsi.h"
#endif

#include "MDD File System/FSIO.h"

#ifdef USE_USB_INTERFACE

typedef struct 
{
    union
    {
        BYTE    value;
        struct
        {
            BYTE        mediaPresent            : 1;
            BYTE        cannotInitialize        : 1;
            BYTE        overcurrentStateUSB     : 1;
        };
    };
} MEDIA_STATUS;

MEDIA_STATUS mediaStatus;

volatile BOOL deviceAttached;

#endif

#ifdef STACK_USE_MDD
volatile BOOL MemInterfaceAttached=FALSE;
#endif 

// Declare AppConfig structure and some other supporting stack variables
APP_CONFIG AppConfig;

// Private helper functions.
// These may or may not be present in all applications.

//For displaying the current IP address on the LCD.
void DisplayIPValue(IP_ADDR IPVal);

static void InitAppConfig(void);
static void InitializeBoard(void);
static void ProcessIO(void);
#ifdef USE_USB_INTERFACE
static void MonitorMedia( void );
#endif


// C30 Exception Handlers
// If your code gets here, you either tried to read or write
// a NULL pointer, or your application overflowed the stack
// by having too many local variables or parameters declared.

	void _ISR __attribute__((__no_auto_psv__)) _AddressError(void)
	{
	    Nop();
		Nop();
	}
	void _ISR __attribute__((__no_auto_psv__)) _StackError(void)
	{
	    Nop();
		Nop();
	}
	
//
// Main application entry point.
//
int main(void)
{
	static DWORD t = 0;
	static DWORD dwLastIP = 0;
	BOOL FileSysInitLock=FALSE;

	// Initialize application specific hardware
	InitializeBoard();
	
	DelayMs(100);

	strcpypgm2ram((char*)LCDText, "PIC24 Web Server" 
	"TCPStack " TCPIP_STACK_VERSION "  "
		);

	LCDUpdate();
	
#ifdef USE_USB_INTERFACE
    deviceAttached = FALSE;
    //Initialize the stack
    USBInitialize(0);
#endif

	// Initialize stack-related hardware components that may be 
	// required by the UART configuration routines
    TickInit();

	// Initialize Stack and application related NV variables into AppConfig.
	InitAppConfig();
		
	// Initialize core stack layers (MAC, ARP, TCP, UDP) and
	// application modules (HTTP, SNMP, etc.)
    StackInit();

	// Now that all items are initialized, begin the co-operative
	// multitasking loop.  This infinite loop will continuously 
	// execute all stack-related tasks, as well as your own
	// application's functions.  Custom functions should be added
	// at the end of this loop.
    // Note that this is a "co-operative mult-tasking" mechanism
    // where every task performs its tasks (whether all in one shot
    // or part of it) and returns so that other tasks can do their
    // job.
    // If a task needs very long time to do its job, it must be broken
    // down into smaller pieces so that other tasks can have CPU time.
    while(1)
    {
   // This function calls the background tasks necessary to support USB Host
   // operation.  Upon initial insertion of the media, it initializes the file
   // system support .  This function needs to be called regularly so that
   // the media can be intialized in case of reconnect and USB Host related
   // funcions are serviced.
#ifdef USE_USB_INTERFACE
        MonitorMedia();
#endif

#if defined STACK_USE_MDD

		MemInterfaceAttached = MDD_MediaDetect();//Check for USB THumb drive is attached 	

		if(MemInterfaceAttached == TRUE && FileSysInitLock==FALSE)
		{
			FileSysInitLock=FileSystemInit();
		}
		else if(MemInterfaceAttached == FALSE)
		{
			FileSysInitLock=FALSE;
		}
#endif
			
        // Blink LED0 (left most one) every second.
        if(TickGet() - t >= TICK_SECOND/2ul)
        {
            t = TickGet();
            LED0_IO ^= 1;
        }

        // This task performs normal stack task including checking
        // for incoming packet, type of packet and calling
        // appropriate stack entity to process it.
        StackTask();

        // This tasks invokes each of the core stack application tasks
        StackApplications();

		// Process application specific tasks here.		
		ProcessIO();

        // If the local IP address has changed (ex: due to DHCP lease change)
        // write the new IP address to the LCD display
		if(dwLastIP != AppConfig.MyIPAddr.Val)
		{
			dwLastIP = AppConfig.MyIPAddr.Val;
			
			DisplayIPValue(AppConfig.MyIPAddr);
		}
	}
}

// Writes an IP address to the LCD display
void DisplayIPValue(IP_ADDR IPVal)
{
//	printf("%u.%u.%u.%u", IPVal.v[0], IPVal.v[1], IPVal.v[2], IPVal.v[3]);
    BYTE IPDigit[4];
	BYTE i;
#ifdef USE_LCD
	BYTE j;
	BYTE LCDPos=16;
#endif

	for(i = 0; i < sizeof(IP_ADDR); i++)
	{
	    uitoa((WORD)IPVal.v[i], IPDigit);

		#ifdef USE_LCD
			for(j = 0; j < strlen((char*)IPDigit); j++)
			{
				LCDText[LCDPos++] = IPDigit[j];
			}
			if(i == sizeof(IP_ADDR)-1)
				break;
			LCDText[LCDPos++] = '.';
		#endif
	}

	#ifdef USE_LCD
		if(LCDPos < 32u)
			LCDText[LCDPos] = 0;
		LCDUpdate();
	#endif
}

// Processes applications
static void ProcessIO(void)
{

}

/****************************************************************************
  Function:
    static void InitializeBoard(void)

  Description:
    This routine initializes the hardware.  It is a generic initialization
    routine, using definitions in HardwareProfile.h to determine specific 
    initialization.

  Precondition:
    None

  Parameters:
    None - None

  Returns:
    None

  Remarks:
    None
  ***************************************************************************/
static void InitializeBoard(void)
{
	OSCCON = 0x3302;    // Enable secondary oscillator
	CLKDIV = 0x0000;    // Set PLL prescaler (1:1)

	__builtin_write_OSCCONL(OSCCON & 0xBF);  // Unlock PPS
	
	// Configure SPI1 PPS pins (ENC28J60)
	RPOR10bits.RP21R  = 8;	// Assign RP21 to SCK1 (output)
	RPOR9bits.RP19R   = 7;	// Assign RP19 to SDO1 (output)
	RPINR20bits.SDI1R = 26;	// Assign RP26 to SDI1 (input)
	
	// Configure UART2 PPS pins 
	RPINR19bits.U2RXR = 10;	// Assign RF4/RP10 to U2RX (input)
	RPOR8bits.RP17R   = 5;  // Assign RF5/RP17 to U2TX (output)
	
	__builtin_write_OSCCONL(OSCCON | 0x40);  // Lock PPS
									
	// LEDs
	LED0_TRIS = 0;
	LED1_TRIS = 0;
	LED2_TRIS = 0;
	LED3_TRIS = 0;
	LED4_TRIS = 0;
	LED5_TRIS = 0;
	LED6_TRIS = 0;
	LED7_TRIS = 0;

	LED0_IO   = 0;	
	LED1_IO   = 0;
	LED2_IO   = 0;
	LED3_IO   = 0;
	LED4_IO   = 0;
	LED5_IO   = 0;
	LED6_IO   = 0;
	LED7_IO   = 0;
	
	// ADC
	AD1PCFG = 0xFFFE;               // Disable digital input on AN0 (Temp sensor)						
	AD1CHS = 0;				   	    // Input to AN0 (Temp sensor)
	Temp_TRIS           = 1;
    AD1CON1             = 0x00E4;   // Off, Auto sample start, auto-convert
    AD1CON1bits.FORM    = 0x0;    
    AD1CON1bits.ADON    = 1;        // Start A/D in continuous mode
    AD1CON2             = 0;        // AVdd, AVss, int every conversion, MUXA only
    AD1CON3             = 0x1F05;   // 31 Tad auto-sample, Tad = 5*Tcy
    AD1CSSL             = 0x0000;   
	
	#if defined(USE_UART_SHOW)	
	UART_SHOW_Init();
	#endif
	
	//ENC28J60
	ENC_CS_IO = 1;
	ENC_CS_TRIS = 0;
	
   //Turn on the Power of USB & LCD Port
	LCD_USB_POWER_TRIS = 0;
	Nop();
	LCD_USB_POWER_IO   = 1;
	Nop();Nop();Nop();
	
	// Initialize the LCD
	LCDInit();	
	
	//USB	
	USBHost_PORT_TRIS = 0;
	USBHost_PORT_IO = 0;
	Nop();Nop();Nop();
}

/*********************************************************************
 * Function:        void InitAppConfig(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        None
 *
 * Note:            Setup the TCPIP stack config variable
 ********************************************************************/

static ROM BYTE SerializedMACAddress[6] = {MY_DEFAULT_MAC_BYTE1, MY_DEFAULT_MAC_BYTE2, MY_DEFAULT_MAC_BYTE3, MY_DEFAULT_MAC_BYTE4, MY_DEFAULT_MAC_BYTE5, MY_DEFAULT_MAC_BYTE6};

static void InitAppConfig(void)
{
	AppConfig.Flags.bIsDHCPEnabled = TRUE;
	AppConfig.Flags.bInConfigMode = TRUE;
	memcpypgm2ram((void*)&AppConfig.MyMACAddr, (ROM void*)SerializedMACAddress, sizeof(AppConfig.MyMACAddr));

	AppConfig.MyIPAddr.Val = MY_DEFAULT_IP_ADDR_BYTE1 | MY_DEFAULT_IP_ADDR_BYTE2<<8ul | MY_DEFAULT_IP_ADDR_BYTE3<<16ul | MY_DEFAULT_IP_ADDR_BYTE4<<24ul;
	AppConfig.DefaultIPAddr.Val = AppConfig.MyIPAddr.Val;
	AppConfig.MyMask.Val = MY_DEFAULT_MASK_BYTE1 | MY_DEFAULT_MASK_BYTE2<<8ul | MY_DEFAULT_MASK_BYTE3<<16ul | MY_DEFAULT_MASK_BYTE4<<24ul;
	AppConfig.DefaultMask.Val = AppConfig.MyMask.Val;
	AppConfig.MyGateway.Val = MY_DEFAULT_GATE_BYTE1 | MY_DEFAULT_GATE_BYTE2<<8ul | MY_DEFAULT_GATE_BYTE3<<16ul | MY_DEFAULT_GATE_BYTE4<<24ul;
	AppConfig.PrimaryDNSServer.Val = MY_DEFAULT_PRIMARY_DNS_BYTE1 | MY_DEFAULT_PRIMARY_DNS_BYTE2<<8ul  | MY_DEFAULT_PRIMARY_DNS_BYTE3<<16ul  | MY_DEFAULT_PRIMARY_DNS_BYTE4<<24ul;
	AppConfig.SecondaryDNSServer.Val = MY_DEFAULT_SECONDARY_DNS_BYTE1 | MY_DEFAULT_SECONDARY_DNS_BYTE2<<8ul  | MY_DEFAULT_SECONDARY_DNS_BYTE3<<16ul  | MY_DEFAULT_SECONDARY_DNS_BYTE4<<24ul;

	// Load the default NetBIOS Host Name
	memcpypgm2ram(AppConfig.NetBIOSName, (ROM void*)MY_DEFAULT_HOST_NAME, 16);
	FormatNetBIOSName(AppConfig.NetBIOSName);
}

#ifdef USE_USB_INTERFACE
/****************************************************************************
  Function:
    BOOL USB_ApplicationEventHandler( BYTE address, USB_EVENT event,
                void *data, DWORD size )

  Summary:
    This is the application event handler.  It is called when the stack has
    an event that needs to be handled by the application layer rather than
    by the client driver.

  Description:
    This is the application event handler.  It is called when the stack has
    an event that needs to be handled by the application layer rather than
    by the client driver.  If the application is able to handle the event, it
    returns TRUE.  Otherwise, it returns FALSE.

  Precondition:
    None

  Parameters:
    BYTE address    - Address of device where event occurred
    USB_EVENT event - Identifies the event that occured
    void *data      - Pointer to event-specific data
    DWORD size      - Size of the event-specific data

  Return Values:
    TRUE    - The event was handled
    FALSE   - The event was not handled

  Remarks:
    The application may also implement an event handling routine if it
    requires knowledge of events.  To do so, it must implement a routine that
    matches this function signature and define the USB_HOST_APP_EVENT_HANDLER
    macro as the name of that function.
  ***************************************************************************/

BOOL USB_ApplicationEventHandler( BYTE address, USB_EVENT event, void *data, DWORD size )
{
    switch( event )
    {
        case EVENT_VBUS_REQUEST_POWER:
            // The data pointer points to a byte that represents the amount of power
            // requested in mA, divided by two.  If the device wants too much power,
            // we reject it.
            return TRUE;

        case EVENT_VBUS_RELEASE_POWER:
            // Turn off Vbus power.This means that the device was removed
            deviceAttached = FALSE;
            return TRUE;
            break;

        case EVENT_HUB_ATTACH:
            return TRUE;
            break;

        case EVENT_UNSUPPORTED_DEVICE:
            return TRUE;
            break;

        case EVENT_CANNOT_ENUMERATE:
            return TRUE;
            break;

        case EVENT_CLIENT_INIT_ERROR:
            return TRUE;
            break;

        case EVENT_OUT_OF_MEMORY:
            return TRUE;
            break;

        case EVENT_UNSPECIFIED_ERROR:   // This should never be generated.
            return TRUE;
            break;

        default:
            break;
    }

    return FALSE;
}


/****************************************************************************
  Function:
    void MonitorMedia( void )

  Description:
    This function detects the USB, SD card/CF card presence. 
    For the USB, SD/CF card this is a Function pointer to the Media Detect Physical Layer function.
    This function calls the background tasks necessary to support USB Host
    operation.  Upon initial insertion of the media, it initializes the file
    system support and reads the volume label.  Upon removal of the media,
    the volume label is marked invalid.

  Precondition:
    None

  Parameters:
    None

  Returns:
    None

  Remarks:
    None
  ***************************************************************************/

void MonitorMedia( void )
{
#ifdef USE_USB_INTERFACE

    BYTE            mediaPresentNow;
    BYTE            mountTries;
    USBTasks();

   // An overcurrent situation is not monitored
    mediaPresentNow = USBHostMSDSCSIMediaDetect();
    if (!mediaPresentNow)
    {
        mediaStatus.cannotInitialize = FALSE;
    }    
    if ((mediaPresentNow != mediaStatus.mediaPresent) && !mediaStatus.cannotInitialize)
    {
        if (mediaPresentNow)
        {
            mountTries = 10;
            while(!FSInit() && --mountTries);
            if (!mountTries)
            {
                mediaStatus.mediaPresent       = FALSE;
                mediaStatus.cannotInitialize   = TRUE;
            }
            else
            {
                mediaStatus.mediaPresent = TRUE;
            }
        }
        else
        {
            mediaStatus.mediaPresent   = FALSE;
        }
    }
#endif
}


#endif
