/*********************************************************************
 *
 *	Hardware specific definitions
 *
 *********************************************************************
 * FileName:        HardwareProfile.h
 * Dependencies:    None
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F, PIC32
 * Compiler:        Microchip C32 v1.10 or higher
 *					Microchip C30 v3.12 or higher
 *					Microchip C18 v3.34 or higher
 *					HI-TECH PICC-18 PRO 9.63PL2 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright (C) 2002-2009 Microchip Technology Inc.  All rights
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and
 * distribute:
 * (i)  the Software when embedded on a Microchip microcontroller or
 *      digital signal controller product ("Device") which is
 *      integrated into Licensee's product; or
 * (ii) ONLY the Software driver source files ENC28J60.c, ENC28J60.h,
 *		ENCX24J600.c and ENCX24J600.h ported to a non-Microchip device
 *		used in conjunction with a Microchip ethernet controller for
 *		the sole purpose of interfacing with the ethernet controller.
 *
 * You should refer to the license agreement accompanying this
 * Software for additional information regarding your rights and
 * obligations.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 *
 * Author               Date		Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Howard Schlunder		10/03/06	Original, copied from Compiler.h
 * Ken Hesky            07/01/08    Added ZG2100-specific features
 * Yale       	        09/03/10	Port to PIC24 Web Server Demo Board
 ********************************************************************/
#ifndef __HARDWARE_PROFILE_H
#define __HARDWARE_PROFILE_H

#include "GenericTypeDefs.h"
#include "Compiler.h"

#define USE_USB_INTERFACE
#define EXPLORER_16		

// Set configuration fuses (but only once)
#if defined(THIS_IS_STACK_APPLICATION)

	#if defined(__PIC24F__)
		_CONFIG1( JTAGEN_OFF & GCP_OFF & GWRP_OFF & COE_OFF & FWDTEN_OFF & ICS_PGx2) 
		_CONFIG2( PLL_96MHZ_ON & IESO_OFF & FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMOD_HS & FNOSC_PRIPLL & PLLDIV_DIV5 & IOL1WAY_ON)
   	#endif
	
#endif // Prevent more than one set of config fuse definitions

// Clock frequency value.
// This value is used to calculate Tick Counter value
#if defined(__PIC24F__)	
	// PIC24F processor
	#define GetSystemClock()		(32000000ul)      // Hz
	#define GetInstructionClock()	(GetSystemClock()/2)
	#define GetPeripheralClock()	GetInstructionClock()

#endif

// Hardware mappings
#if defined(EXPLORER_16)

	#define LED0_TRIS			(TRISBbits.TRISB9)	// Ref D2
	#define LED0_IO				(LATBbits.LATB9)	
	#define LED1_TRIS			(TRISBbits.TRISB8)	// Ref D3
	#define LED1_IO				(LATBbits.LATB8)	
	#define LED2_TRIS			(TRISFbits.TRISF3)	// Ref D4
	#define LED2_IO				(LATFbits.LATF3)
	#define LED3_TRIS			(TRISBbits.TRISB14)	// Ref D5
	#define LED3_IO				(LATBbits.LATB14)
	#define LED4_TRIS			(TRISFbits.TRISF1)	// Ref D6
	#define LED4_IO				(LATFbits.LATF1)
	#define LED5_TRIS			(TRISFbits.TRISF0)	// Ref D7
	#define LED5_IO				(LATFbits.LATF0)
	#define LED6_TRIS			(TRISDbits.TRISD7)	// Ref D8
	#define LED6_IO				(LATDbits.LATD7)
	#define LED7_TRIS			(TRISDbits.TRISD6)	// Ref D9	
	#define LED7_IO				(LATDbits.LATD6)
	#define LED_GET()			(*((volatile unsigned char*)(&LATB)))
	#define LED_PUT(a)			(*((volatile unsigned char*)(&LATB)) = (a))


	#define BUTTON0_TRIS		(TRISBbits.TRISB4)	// Ref S1
	#define	BUTTON0_IO			(PORTBbits.RB4)
	#define BUTTON1_TRIS		(TRISBbits.TRISB3)	// Ref S2	// Note: This is multiplexed with LED7
	#define	BUTTON1_IO			(PORTBbits.RB3)
	#define BUTTON2_TRIS		(TRISBbits.TRISB2)	// Ref S3
	#define	BUTTON2_IO			(PORTBbits.RB2)

	#define Temp_TRIS		    (TRISBbits.TRISB0)	// Ref AN

	#define UARTTX_TRIS			(TRISFbits.TRISF5)
	#define UARTTX_IO			(PORTFbits.RF5)
	#define UARTRX_TRIS			(TRISFbits.TRISF4)
	#define UARTRX_IO			(PORTFbits.RF4)

	// ENC28J60 I/O pins
	#define ENC_CS_TRIS			(TRISDbits.TRISD8)	// Comment this line out if you are using the ENC424J600/624J600, ZeroG ZG2100, or other network controller.
	#define ENC_CS_IO			(PORTDbits.RD8)
	#define ENC_RST_TRIS		(TRISCbits.TRISC14)	// Not connected by default.  It is okay to leave this pin completely unconnected, in which case this macro should simply be left undefined.
	#define ENC_RST_IO	        (PORTCbits.RC14)
	// SPI SCK, SDI, SDO pins are automatically controlled by the PIC24 SPI module 
	#define ENC_SPI_IF			(IFS0bits.SPI1IF)
	#define ENC_SSPBUF			(SPI1BUF)
	#define ENC_SPISTAT			(SPI1STAT)
	#define ENC_SPISTATbits		(SPI1STATbits)
	#define ENC_SPICON1			(SPI1CON1)
	#define ENC_SPICON1bits		(SPI1CON1bits)
	#define ENC_SPICON2			(SPI1CON2)
	
	// Select which UART the STACK_USE_UART and STACK_USE_UART2TCP_BRIDGE 
	// options will use.  You can change these to U1BRG, U1MODE, etc. if you 
	// want to use the UART1 module instead of UART2.
	
	// Define the baud rate constants
	#if defined(__C30__)
    	#define BAUDRATE2       57600UL         // Desired baud rate
    	#define BRG_DIV2        16              // BRG baud rate divider
    	#define BRGH2           0               // BRGH bit value
	#elif defined (__PIC32MX__)
   	 	#define BAUDRATE2       57600UL
    	#define BRG_DIV2        16 
    	#define BRGH2           0 
	#endif

	#define UBRG					U2BRG
	#define UMODE					U2MODE
	#define USTA					U2STA
	#define BusyUART()				BusyUART2()
	#define CloseUART()				CloseUART2()
	#define ConfigIntUART(a)		ConfigIntUART2(a)
	#define DataRdyUART()			DataRdyUART2()
	#define OpenUART(a,b,c)			OpenUART2(a,b,c)
	#define ReadUART()				ReadUART2()
	#define WriteUART(a)			WriteUART2(a)
	#define getsUART(a,b,c)			getsUART2(a,b,c)
	#define putsUART(a)				putsUART2((unsigned int*)a)
	#define getcUART()				getcUART2()
	#define putcUART(a)				do{while(BusyUART()); WriteUART(a); while(BusyUART()); }while(0)
	#define putrsUART(a)			putrsUART2(a)

	// LCD Module I/O pins.  NOTE: On the Explorer 16, the LCD is wired to the 
	// same PMP lines required to communicate with an ENCX24J600 in parallel 
	// mode.  Since the LCD does not have a chip select wire, if you are using 
	// the ENC424J600/624J600 in parallel mode, the LCD cannot be used.

	#define LCD_DATA_TRIS		(*((volatile BYTE*)&TRISE))
	#define LCD_DATA_IO			(*((volatile BYTE*)&LATE))
	#define LCD_RD_WR_TRIS		(TRISDbits.TRISD5)
	#define LCD_RD_WR_IO		(LATDbits.LATD5)
	#define LCD_RS_TRIS			(TRISBbits.TRISB15)
	#define LCD_RS_IO			(LATBbits.LATB15)
	#define LCD_E_TRIS			(TRISDbits.TRISD11)
	#define LCD_E_IO			(LATDbits.LATD11)
	#define LCD_LIGHT_TRIS		(TRISDbits.TRISD1)
	#define LCD_LIGHT_IO		(LATDbits.LATD1)
	#define LCD_COMPARE_TRIS	(TRISDbits.TRISD2)
	#define LCD_COMPARE_IO		(LATDbits.LATD2)
		
	#define USBHost_PORT_IO     (LATDbits.LATD10)
	#define USBHost_PORT_TRIS   (TRISDbits.TRISD10)
	
	#define LCD_USB_POWER_IO    (LATBbits.LATB5)
	#define LCD_USB_POWER_TRIS  (TRISBbits.TRISB5)		

#endif


	
// Macros for input and output TRIS bits
#define INPUT_PIN   1
#define OUTPUT_PIN  0

#endif


