/******************************************************************************
*  Copyright(c) 2010  
*  All right reserved  Sure Electronics Co., Ltd.
*
*  File Name:        UARTShow.h 
*  Product Version�� V1.0  

Author          Date                Comments
---------------------------------------------------------------------------
Yale          2010.09.03          
 
*******************************************************************************/

#ifndef __UART_SHOW_H
#define __UART_SHOW_H

#define RX_BUFFER_SIZE 16 

extern BYTE RX_Buffer[RX_BUFFER_SIZE];
extern volatile BYTE *PtrRX_WRdata;
extern int RX_index;

void UART_SHOW_Init(void);

#endif
