/******************************************************************************
*  Copyright(c) 2010  
*  All right reserved  Sure Electronics Co., Ltd.
*
*  File Name:        UART_Show.c 
*  Product Version�� V1.0  

Author          Date                Comments
---------------------------------------------------------------------------
Yale          2010.09.03          
 
*******************************************************************************/

#define __UART_SHOW_C

#include "TCPIPConfig.h"
#include "HardwareProfile.h"

#define BAUD_RATE			9600

#if defined(USE_UART_SHOW)

#include "TCPIP Stack/TCPIP.h"

BYTE RX_Buffer[RX_BUFFER_SIZE]; 
volatile BYTE *PtrRX_WRdata = RX_Buffer;
int RX_index = 0;

void UART_SHOW_Init(void)
{
	UARTTX_TRIS = 0;
	UARTRX_TRIS = 1;
	UMODE = 0x8000;	    // Set UARTEN.  Note: this must be done before setting UTXEN
	USTA  = 0x0400;		// UTXEN set
	
	#define CLOSEST_UBRG_VALUE ((GetPeripheralClock()+8ul*BAUD_RATE)/16/BAUD_RATE-1)
	#define BAUD_ACTUAL        (GetPeripheralClock()/16/(CLOSEST_UBRG_VALUE+1))
	#define BAUD_ERROR         ((BAUD_ACTUAL > BAUD_RATE) ? BAUD_ACTUAL-BAUD_RATE : BAUD_RATE-BAUD_ACTUAL)
	#define BAUD_ERROR_PRECENT ((BAUD_ERROR*100+BAUD_RATE/2)/BAUD_RATE)
	#if (BAUD_ERROR_PRECENT > 3)
		#warning UART frequency error is worse than 3%
	#elif (BAUD_ERROR_PRECENT > 2)
		#warning UART frequency error is worse than 2%
	#endif
	UBRG = CLOSEST_UBRG_VALUE;
	
	IFS1bits.U2RXIF = 0;	
	IEC1bits.U2RXIE = 1;
}

void _ISR __attribute__((__no_auto_psv__)) _U2RXInterrupt(void)
{	
	IFS1bits.U2RXIF = 0;
	{
		*PtrRX_WRdata++ = U2RXREG;
		RX_index++;	
		if(PtrRX_WRdata >= RX_Buffer + RX_BUFFER_SIZE)
		{	
			PtrRX_WRdata = RX_Buffer;
			RX_index = 0;
		}	
	}	              
}


#endif	//USE_UART_SHOW
